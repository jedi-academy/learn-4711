<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-02-26 12:44:34 --> Class 'CodeIgniter\Resources\ResourceController' not found
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-02-26 12:45:02 --> Class 'CodeIgniter\Resources\ResourceController' not found
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-02-26 12:45:07 --> Class 'CodeIgniter\Resources\ResourceController' not found
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2019-02-26 12:49:02 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:50:30 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:51:16 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:51:50 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:53:26 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:54:04 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 12:59:53 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 13:03:00 --> Call to undefined method App\Controllers\RawBlocksAPI::modelName()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 13:12:14 --> Class 'App\Controllers\App\Models\Blocks' not found
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(801): CodeIgniter\Resource\ResourceController->initController(Object(CodeIgniter\HTTP\IncomingRequest), Object(CodeIgniter\HTTP\Response), Object(CodeIgniter\Log\Logger))
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(320): CodeIgniter\CodeIgniter->createController()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
CRITICAL - 2019-02-26 13:21:09 --> Array to string conversion
#0 C:\Users\a00195498\playful\app\Controllers\BlockPresenter.php(16): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Array to string...', 'C:\\Users\\a00195...', 16, Array)
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(825): App\Controllers\BlockPresenter->index()
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BlockPresenter))
#3 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#5 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#6 {main}
CRITICAL - 2019-02-26 13:22:27 --> Call to undefined method App\Controllers\BlockPresenter::respond()
#0 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(825): App\Controllers\BlockPresenter->index()
#1 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BlockPresenter))
#2 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\CodeIgniter.php(235): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\Users\a00195498\playful\public\index.php(44): CodeIgniter\CodeIgniter->run()
#4 C:\Users\a00195498\playful\vendor\codeigniter4\codeigniter4\system\Commands\Server\rewrite.php(39): require_once('C:\\Users\\a00195...')
#5 {main}
