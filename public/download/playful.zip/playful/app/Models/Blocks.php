<?php

namespace App\Models;

use CodeIgniter\Model;

class Blocks extends Model {

    protected $table = 'blocks';
    protected $primaryKey = 'code';
    protected $allowedFields = ['name', 'status', 'cap', 'notes'];
    protected $validationRules = [
        'name' => 'required|alpha_numeric|exact_length[6]]',
        'status' => 'alpha',
        'cap' => 'required|integer|less_than[31]',
        'notes' => 'max_length[128]'
    ];

}
