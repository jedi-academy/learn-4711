<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Blocks;
use CodeIgniter\API\ResponseTrait;

class BlockPresenter extends Controller {

    use ResponseTrait;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger) {
        parent::initController($request, $response, $logger);
        $this->blocks = new Blocks();
    }

    public function index() {
        return view('the_blocks',['records'=>$this->blocks->findAll()]);
    }

    // show a block
    public function show($id) {
        return view('one_block',['record'=>$this->blocks->find($id)]);
   }
    
    // present a block for editing
    public function edit($id) {
        return view('edit_block',['record'=>$this->blocks->find($id)]);
    }
    // process a block update
    public function update($id) {
        // extract data from form (request->getVar)
        // run the validation, against blocks->getValidationRules
        // if ok, blocks->update($data)b&Bshow success?
        // else redisplay the form with errors
        return 'ok';
    }
    //--------------------------------------------------------------------
}
