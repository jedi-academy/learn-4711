<?php

namespace App\Controllers;

use CodeIgniter\Resource\ResourceController;

class RawBlocksAPI extends ResourceController {

    protected $modelName = '\App\Models\Blocks';

}
