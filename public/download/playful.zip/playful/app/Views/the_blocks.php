<!doctype html>
<html>
    <head>
        <title>Walkthrough</title>

        <link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
    </head>
    <body>

        <ul>
            <?php
            foreach ($records as $record) {
                echo '<li>' .
                '<a href="/BlockPresenter/show/' . $record['code'] . '">' . $record['code'] . '</a>' .
                ': ' . $record['name'] .
                '<a href="/BlockPresenter/edit/' . $record['code'] . '"> Edit</a>' . '</li>';
            }
            ?>

        </ul>
    </body>
</html>
