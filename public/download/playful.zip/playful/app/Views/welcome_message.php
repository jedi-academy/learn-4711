<!doctype html>
<html>
	<head>
		<title>Walkthrough</title>

		<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
	</head>
	<body>

            <p><a href="/">Home</a></p>
            <p><a href="/BlockPresenter">Presenter</a></p>
            <p><a href="/blocks">Raw API</a></p>

	</body>
</html>
